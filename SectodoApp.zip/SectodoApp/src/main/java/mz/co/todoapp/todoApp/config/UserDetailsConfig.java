package mz.co.todoapp.todoApp.config;

import mz.co.todoapp.todoApp.entity.User;
import mz.co.todoapp.todoApp.exception.ResourceNotFoundException;
import mz.co.todoapp.todoApp.repository.UserRepository;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

@Configuration
public class UserDetailsConfig implements UserDetailsService {

   private final UserRepository userRepository;

    public UserDetailsConfig(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
            User user = userRepository.findByEmail(email).orElseThrow(() -> new
                    ResourceNotFoundException("User not found"));


        return user;
    }
}
