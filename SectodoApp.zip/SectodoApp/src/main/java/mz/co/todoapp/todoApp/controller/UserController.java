package mz.co.todoapp.todoApp.controller;

import lombok.AllArgsConstructor;
import mz.co.todoapp.todoApp.dto.TaskDto;
import mz.co.todoapp.todoApp.dto.UserDto;
import mz.co.todoapp.todoApp.entity.Role;
import mz.co.todoapp.todoApp.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@AllArgsConstructor
@RequestMapping("api/users")
public class UserController {

    UserService userService;

//     @Bean
//     private final PasswordEncoder passwordEncoder(){
//         return new BCryptPasswordEncoder();
//     }

//    @PreAuthorize("hasRole('ROLE_USER')")
    @PostMapping("/new")
    public ResponseEntity<UserDto> addTask(@RequestBody UserDto userDto){
        // userDto.setPassword(passwordEncoder().encode(userDto.getPassword()));
        UserDto savedUser = userService.createUser(userDto);

        return new ResponseEntity(savedUser, HttpStatus.CREATED);

    }


    @PutMapping("/{id}")
    public ResponseEntity<UserDto> updateUser(@RequestBody UserDto userDto, @PathVariable UUID id){
        UserDto updatedUser = userService.updateUser(userDto, id);

        return new ResponseEntity<>(updatedUser, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getTasks(@PathVariable UUID id){
        UserDto returnedUser = userService.getUser(id);
       return new ResponseEntity<>(returnedUser, HttpStatus.OK);

    }



    @GetMapping("/all")
    public ResponseEntity<List<UserDto>> getAllUsers(){
        List<UserDto> allUsers = userService.getAllUsers();

        return new ResponseEntity<>(allUsers, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public String deleteTask(@PathVariable UUID id){
        userService.deleteUser(id);
        return "User deleted successfully";
    }


    @GetMapping("/roles")
    public ResponseEntity<List<Role>> getAllRoles(){
        List<Role> allRoles = userService.getAllRoles();

        return new ResponseEntity<>(allRoles, HttpStatus.OK);
    }


    @PatchMapping("/assign/{id}")
    public UserDto assignRole(@PathVariable UUID id, @RequestBody Map<String, Object> name) {

        return  userService.assignRole(id, (String) name.get("name"));
    }




}
