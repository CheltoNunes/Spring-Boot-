package mz.co.todoapp.todoApp.service;

import mz.co.todoapp.todoApp.dto.TaskDto;
import mz.co.todoapp.todoApp.dto.UserDto;
import mz.co.todoapp.todoApp.entity.Role;

import java.util.List;
import java.util.UUID;

public interface UserService {

    UserDto createUser(UserDto userDto);

    UserDto updateUser(UserDto userDto, UUID id);
    UserDto getUser(UUID id);

    List<UserDto> getAllUsers();

    void deleteUser(UUID id);

    List<Role> getAllRoles();

    UserDto assignRole(UUID id, String name);
}
