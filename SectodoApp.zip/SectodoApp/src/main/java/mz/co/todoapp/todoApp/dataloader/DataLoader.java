package mz.co.todoapp.todoApp.dataloader;


import lombok.RequiredArgsConstructor;
import mz.co.todoapp.todoApp.entity.Role;
import mz.co.todoapp.todoApp.entity.Status;
import mz.co.todoapp.todoApp.repository.RoleRepository;
import mz.co.todoapp.todoApp.repository.StatusRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private final StatusRepository statusRepository;
    private final RoleRepository roleRepository;


    @Override
    public void run(String... args) throws Exception {



        if (statusRepository.count() == 0) {
            statusRepository.save(new Status(UUID.randomUUID(), Status.NOT_STARTED));
            statusRepository.save(new Status(UUID.randomUUID(), Status.IN_PROGRESS));
            statusRepository.save(new Status(UUID.randomUUID(), Status.COMPLETED));
            statusRepository.save(new Status(UUID.randomUUID(), Status.CANCELED));
        }
        if (roleRepository.count() == 0){
            roleRepository.save(new Role(UUID.randomUUID(), Role.ADMIN));
            roleRepository.save(new Role(UUID.randomUUID(), Role.MANAGER));
            roleRepository.save(new Role(UUID.randomUUID(), Role.USER));
        }
    }
}
