package mz.co.todoapp.todoApp.service.impl;

import lombok.AllArgsConstructor;
import mz.co.todoapp.todoApp.dto.UserDto;
import mz.co.todoapp.todoApp.entity.Role;
import mz.co.todoapp.todoApp.entity.Status;
import mz.co.todoapp.todoApp.entity.Task;
import mz.co.todoapp.todoApp.entity.User;
import mz.co.todoapp.todoApp.exception.ResourceNotFoundException;
import mz.co.todoapp.todoApp.repository.RoleRepository;
import mz.co.todoapp.todoApp.repository.UserRepository;
import mz.co.todoapp.todoApp.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public UserDto createUser(UserDto userDto) {
        Role role = roleRepository.findByName(Role.USER);
        if (role == null) {
            throw new RuntimeException("Role Not Found");
        }

        User user = modelMapper.map(userDto, User.class);
        user.setRole(role);
        user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        User savedUser = userRepository.save(user);

        return modelMapper.map(savedUser, UserDto.class);
    }

    @Override
    public UserDto updateUser(UserDto userDto, UUID id) {
        User user = userRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("User not found with id : " + id));

        user.setFullName(userDto.getFullName());
        user.setEmail(userDto.getEmail());
        user.setPassword(userDto.getPassword());


        User updatedUser = userRepository.save(user);
        return modelMapper.map(updatedUser, UserDto.class);
    }

    @Override
    public UserDto getUser(UUID id) {
        User user = userRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("User not found with id : " + id));
        return modelMapper.map(user, UserDto.class);
    }

    @Override
    public List<UserDto> getAllUsers() {
        List<User> userList = userRepository.findAll();

        return userList.stream().map((user) -> modelMapper.map(user, UserDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public void deleteUser(UUID id) {
        User user = userRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("User not found with id : " + id));
        user.setRole(null);
        userRepository.save(user);
        userRepository.deleteById(id);
    }

    @Override
    public List<Role> getAllRoles() {
        List<Role> roleList = roleRepository.findAll();

        return roleList;
    }

    @Override
    public UserDto assignRole(UUID id, String name) {
        User user = userRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("User not found with id : " + id));

        Role role = roleRepository.findByName(name);
        System.out.println(role.getName());
        if (role == null) {
            throw new RuntimeException("Role not found");
        }
        user.setRole(role);
        User updatedUser = userRepository.save(user);

        return modelMapper.map(updatedUser, UserDto.class);
    }

}
