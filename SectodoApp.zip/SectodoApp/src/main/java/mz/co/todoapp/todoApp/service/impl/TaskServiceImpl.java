package mz.co.todoapp.todoApp.service.impl;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import mz.co.todoapp.todoApp.dto.TaskDto;
import mz.co.todoapp.todoApp.entity.Status;
import mz.co.todoapp.todoApp.entity.Task;
import mz.co.todoapp.todoApp.entity.User;
import mz.co.todoapp.todoApp.exception.ResourceNotFoundException;
import mz.co.todoapp.todoApp.repository.StatusRepository;
import mz.co.todoapp.todoApp.repository.TaskRepository;
import mz.co.todoapp.todoApp.repository.UserRepository;
import mz.co.todoapp.todoApp.service.TaskService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class TaskServiceImpl implements TaskService {

    ModelMapper modelMapper;
    TaskRepository taskRepository;
    @Autowired
    StatusRepository statusRepository;
    UserRepository userRepository;
    @Override
    public TaskDto addTask(TaskDto taskDto) {
        Status status = statusRepository.findByType(Status.NOT_STARTED);
        if (status == null) {
            throw new RuntimeException("Status Not Found");
        }

        Task task = modelMapper.map(taskDto, Task.class);
        task.setStatus(status);
        Task savedTask = taskRepository.save(task);
        return modelMapper.map(savedTask, TaskDto.class);
    }

    @Override
    public TaskDto updateTask(TaskDto taskDto, UUID id) {
        Task task = taskRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("Status not found with id : " + id));
        task.setTitle(taskDto.getTitle());
        task.setDescription(taskDto.getDescription());
        task.setUpdatedDate(taskDto.getUpdatedDate());


    Task updatedTask = taskRepository.save(task);

        return modelMapper.map(updatedTask, TaskDto.class);
    }

    @Override
    public TaskDto getTask(UUID id) {
        Task task = taskRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("Status not found with id : " + id));
        task.getStatus().getType();
        System.out.println(task.getStatus().getType());
        return modelMapper.map(task, TaskDto.class);

    }

    @Override
    public List<TaskDto> getAllTasks() {
        List<Task> taskList = taskRepository.findAll();

        return taskList.stream().map((task) -> modelMapper.map(task, TaskDto.class))
                .collect(Collectors.toList());
    }

    @Override

    public void deleteTask(UUID id) {
        Task task = taskRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("Status not found with id : " + id));

        task.setStatus(null);
        taskRepository.save(task);

        taskRepository.deleteById(id);

    }

    @Override
    public TaskDto updateStatus(UUID id, String type) {
        Task task = taskRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("Status Not Found with id : " + id));
        Status status = statusRepository.findByType(type);
        System.out.println(status.getType());
        if (status == null) {
            throw new RuntimeException("Status Not Found");
        }
        task.setStatus(status);
        Task updatedTask = taskRepository.save(task);

        return modelMapper.map(updatedTask, TaskDto.class);
    }

    @Override
    public TaskDto assignUser(UUID userId, UUID taskId) {
        Task task = taskRepository.findById(taskId).orElseThrow(() -> new
                ResourceNotFoundException("Task not found with id : " + taskId));
        User user = userRepository.findById(userId).orElseThrow(() -> new
                ResourceNotFoundException("User not found with id : " + userId));
        if (task.getUser() == null) {
            task.setUser(user);
        }else {
            System.out.println("This task is assigned to other user"+ task.getUser().getFullName());
        }
        Task updatedTask = taskRepository.save(task);

        return modelMapper.map(updatedTask, TaskDto.class);
    }

    @Override
    public void unassignTaskFromUser(UUID id) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        task.setUser(null);
        taskRepository.save(task);
    }


}
