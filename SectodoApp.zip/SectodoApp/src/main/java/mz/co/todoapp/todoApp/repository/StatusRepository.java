package mz.co.todoapp.todoApp.repository;

import mz.co.todoapp.todoApp.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface StatusRepository extends JpaRepository<Status, UUID> {
  Status findByType(String type);
}
