package mz.co.todoapp.todoApp.service;

import mz.co.todoapp.todoApp.dto.TaskDto;
//import mz.co.todoapp.todoApp.entity.Status;
import mz.co.todoapp.todoApp.entity.Task;

import java.util.List;
import java.util.UUID;

public interface TaskService {

    TaskDto addTask(TaskDto taskDto);

    TaskDto updateTask(TaskDto taskDto, UUID id);

    TaskDto getTask(UUID id);

    List<TaskDto> getAllTasks();

    void deleteTask(UUID id);

    TaskDto updateStatus(UUID id, String type);

    TaskDto assignUser(UUID userId, UUID taskId);

    void unassignTaskFromUser(UUID id);




}
