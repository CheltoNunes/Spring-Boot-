package mz.co.todoapp.todoApp.controller;

import lombok.AllArgsConstructor;
import mz.co.todoapp.todoApp.dto.TaskDto;
import mz.co.todoapp.todoApp.entity.Task;
import mz.co.todoapp.todoApp.service.TaskService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@AllArgsConstructor
@RequestMapping("api/tasks")
public class TaskController {
    TaskService taskService;

    @PostMapping("/new")
    public ResponseEntity<TaskDto> addTask(@RequestBody TaskDto taskDto){
        TaskDto savedTask = taskService.addTask(taskDto);
        return new ResponseEntity(savedTask, HttpStatus.CREATED);

    }

    @PutMapping("{id}")
    public ResponseEntity<TaskDto> updateTask(@RequestBody TaskDto taskDto, @PathVariable UUID id){
        TaskDto updatedTask = taskService.updateTask(taskDto, id);
        return new ResponseEntity<>(updatedTask, HttpStatus.OK);
    }

    @GetMapping("{id}")
    public ResponseEntity<TaskDto> getTasks(@PathVariable UUID id){
        TaskDto returnedTask = taskService.getTask(id);
        return new ResponseEntity<>(returnedTask, HttpStatus.OK);
    }

    //@PreAuthorize("permitAll()")

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/all")
    public ResponseEntity<List<TaskDto>> getAllTasks(){
        List<TaskDto> allTasks = taskService.getAllTasks();
        return new ResponseEntity<>(allTasks, HttpStatus.OK);
    }
    @DeleteMapping("/{id}")
    public String deleteTask(@PathVariable UUID id){

        taskService.deleteTask(id);

        return "Task deleted successfully";
    }

    @PatchMapping("/{id}/update")
   // @PutMapping("/{id}/update")
    public TaskDto updateStatus(@PathVariable UUID id, @RequestBody Map<String, Object> type) {
        return taskService.updateStatus(id, (String) type.get("type"));
    }

//    @PutMapping("/assign/{userId}/{taskId}")
    @PatchMapping("/assign/{userId}/{taskId}")
    public ResponseEntity<TaskDto> assignTask(@PathVariable UUID userId, @PathVariable UUID taskId) {
        TaskDto task = taskService.assignUser(userId, taskId);
        return new ResponseEntity<>(task, HttpStatus.OK);
    }

//    @PutMapping("/unassign/{taskId}")
    @PatchMapping("/unassign/{taskId}")
    public String unAssignTaskFromUser(@PathVariable UUID taskId){
        taskService.unassignTaskFromUser(taskId);

        return "Task unassigned";
    }




}
