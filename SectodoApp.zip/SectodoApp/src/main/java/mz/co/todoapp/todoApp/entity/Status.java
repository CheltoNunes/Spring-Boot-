package mz.co.todoapp.todoApp.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcType;
import org.hibernate.type.descriptor.jdbc.VarcharJdbcType;

import java.util.UUID;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="status")
public class Status {

        @Id
        @JsonIgnore
        @JdbcType(VarcharJdbcType.class)
        private UUID id;
        private String type;

       public static final String NOT_STARTED = "Not Started";
       public static final String IN_PROGRESS = "In Progress";
       public static final String COMPLETED = "Completed";
       public static final String CANCELED = "Canceled";
}
