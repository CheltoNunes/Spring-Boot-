package mz.co.todoapp.todoApp.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mz.co.todoapp.todoApp.entity.Role;

import java.util.UUID;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {


    private UUID id;
    private String fullName;
    private String email;
    private String password;
    private Role role;


}
