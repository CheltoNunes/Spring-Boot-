package mz.co.todoapp.todoApp.repository;

import mz.co.todoapp.todoApp.entity.Role;
import mz.co.todoapp.todoApp.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface RoleRepository extends JpaRepository<Role, UUID> {
    Role findByName(String name);
}
