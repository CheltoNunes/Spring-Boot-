package mz.co.todoapp.todoApp.dto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import mz.co.todoapp.todoApp.entity.Status;
import mz.co.todoapp.todoApp.entity.User;

import java.time.LocalDateTime;
import java.util.UUID;


@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class TaskDto {

    private UUID id;
    private String title;
    private String description;
    private LocalDateTime startDate;
    private LocalDateTime updatedDate;
    private Status status;
    private UserDto user;

}
